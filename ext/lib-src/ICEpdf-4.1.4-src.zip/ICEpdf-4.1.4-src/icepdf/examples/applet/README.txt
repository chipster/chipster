ICEpdf Applet Example Build Information

The Applet example can be build with the provided ant build script.  The
default ant target is icepdf.applet.jar.  Once the build runs successfully all
needed jars and the respective HTML files are copied to the './dist' folder.

The build script does not attempt to sign the jar files however most Applet
deployment scenarios require jar signatures.  More information on how to sign
jars with your own certificate can be found here,
http://java.sun.com/docs/books/tutorial/deployment/jar/signing.html


Additional Resources

For more information about ICEpdf, including community forums, tutorials, etc.
visit the ICEpdf community site: http://www.icepdf.org/

