
fastq-solexa 
  /seq/solexa_archive/gerald_archive/305LWAAXX080721/s_1_sequence.txt

