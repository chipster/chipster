package org.jfree.chart.event.junit;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.awt.*;
import org.jfree.chart.event.*;
import org.jfree.chart.plot.junit.*;
import javax.swing.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.plot.Plot;

/**
 * Tests for the {@link org.jfree.chart.event.SelectionChangeEvent} class.
 */
public class SelectionChangeEventTests extends TestCase {


    /**
     * Returns the tests as a test suite.
     *
     * @return The test suite.
     */
    public static Test suite() {
        return new TestSuite(SelectionChangeEventTests.class);
    }

    /**
     * Constructs a new set of tests.
     *
     * @param name  the name of the tests.
     */
    public SelectionChangeEventTests(String name) {
        super(name);
    }


   /**
    * Does the tests.
    */ 
   public void testGetSelection(){


	try{
	HCPlot plot = new HCPlot(HCPlotTests.createDataset(2,3,true,true));
	Rectangle test = new Rectangle();	

	SelectionChangeEvent event = new SelectionChangeEvent(plot, plot.getSelection());

	Rectangle rct = event.getOldSelection();

	assertTrue(rct.equals(test));

	} catch (Exception e){
		;
	}
   }
}
