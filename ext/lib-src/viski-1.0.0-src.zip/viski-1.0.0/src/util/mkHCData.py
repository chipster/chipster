#!/usr/bin/env python

from random import randint
from random import random
from sys import argv

if len(argv)<2: treeSize=10 # some default
else: treeSize=int(argv[1])

def mktree(size,initialHeight,width):
	if randint(0,size) >= initialHeight:
		print "l"
		return width+1
	else:
		delta = random()*2
		print initialHeight
		width = mktree(size,initialHeight-1,width)
		width = mktree(size,initialHeight-1,width)
		return width


rows = mktree(treeSize-1,treeSize,0)
columns = mktree(treeSize,treeSize,0)

print columns
print rows

count = 0.0
max = 0.0+rows*columns

for i in range(rows):
	for j in range(columns):
		print count - max/2
		#print (random()-0.5)*2.0
		count+=1;

