package org.mortbay.cometd.jms;

import java.util.Enumeration;

import javax.jms.Destination;
import javax.jms.JMSException;

public class CometdMessage implements javax.jms.Message
{

    public void acknowledge() throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void clearBody() throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void clearProperties() throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public boolean getBooleanProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return false;
    }

    public byte getByteProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public double getDoubleProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public float getFloatProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public int getIntProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getJMSCorrelationID() throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public byte[] getJMSCorrelationIDAsBytes() throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public int getJMSDeliveryMode() throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public Destination getJMSDestination() throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public long getJMSExpiration() throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getJMSMessageID() throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public int getJMSPriority() throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public boolean getJMSRedelivered() throws JMSException
    {
        // TODO Auto-generated method stub
        return false;
    }

    public Destination getJMSReplyTo() throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public long getJMSTimestamp() throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getJMSType() throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public long getLongProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public Object getObjectProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public Enumeration getPropertyNames() throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public short getShortProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getStringProperty(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean propertyExists(String name) throws JMSException
    {
        // TODO Auto-generated method stub
        return false;
    }

    public void setBooleanProperty(String name, boolean value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setByteProperty(String name, byte value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setDoubleProperty(String name, double value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setFloatProperty(String name, float value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setIntProperty(String name, int value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSCorrelationID(String correlationID) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSCorrelationIDAsBytes(byte[] correlationID) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSDeliveryMode(int deliveryMode) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSDestination(Destination destination) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSExpiration(long expiration) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSMessageID(String id) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSPriority(int priority) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSRedelivered(boolean redelivered) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSReplyTo(Destination replyTo) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSTimestamp(long timestamp) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setJMSType(String type) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setLongProperty(String name, long value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setObjectProperty(String name, Object value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setShortProperty(String name, short value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

    public void setStringProperty(String name, String value) throws JMSException
    {
        // TODO Auto-generated method stub
        
    }

}
