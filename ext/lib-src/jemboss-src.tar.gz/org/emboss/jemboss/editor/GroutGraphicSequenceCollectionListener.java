package org.emboss.jemboss.editor;

/**
 * GroutGraphicSequenceCollectionListener.java
 *
 *
 * Created: Thu Mar 13 14:42:13 2003
 *
 * @author <a href="mailto:">Mr H. Morgan</a>
 * @version
 */

public interface GroutGraphicSequenceCollectionListener
{
  
  public abstract void groutGraphicSequenceCollectionChanged(GroutGraphicSequenceCollectionEvent e);
  
}

