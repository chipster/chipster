package org.emboss.jemboss.editor;

/**
 * GroutAlignJFrameListener.java
 *
 *
 * Created: 10th June 2003
 *
 * @author <a href="mailto:">Mr H. Morgan</a>
 * @version
 */

public interface GroutAlignJFrameListener
{
  
  public abstract void groutAlignJFrameChanged(GroutAlignJFrameEvent e);
  
}

