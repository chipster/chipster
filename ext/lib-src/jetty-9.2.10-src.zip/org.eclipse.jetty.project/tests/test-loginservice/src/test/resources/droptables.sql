DROP TABLE roles;

DROP TABLE users;

DROP TABLE user_roles;

